/* Xem Tài Liệu - logic giao diện & render tài liệu */
(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const native = window.Android || null; // cầu nối Kotlin (null khi chạy thử trên trình duyệt)

  pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';

  let current = null;      // {name, mime, size, url | blob}
  let renderToken = 0;     // huỷ render cũ khi mở file mới
  let pdfObserver = null;

  // ---------- Tiện ích ----------
  const extOf = (name) => (name.split('.').pop() || '').toLowerCase();
  function kindOf(name, mime) {
    const e = extOf(name || '');
    mime = mime || '';
    if (e === 'pdf' || mime === 'application/pdf') return 'pdf';
    if (['docx', 'docm', 'dotx'].includes(e) || mime.includes('wordprocessingml')) return 'docx';
    if (e === 'doc' || mime === 'application/msword') return 'doc';
    if (['xlsx', 'xlsm', 'xlsb', 'xls', 'ods', 'csv', 'tsv'].includes(e) || mime.includes('spreadsheet') || mime.includes('ms-excel') || mime === 'text/csv') return 'xlsx';
    if (['pptx', 'ppsx', 'pptm', 'potx'].includes(e) || mime.includes('presentationml')) return 'pptx';
    if (e === 'ppt' || mime === 'application/vnd.ms-powerpoint') return 'ppt';
    if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg'].includes(e) || mime.startsWith('image/')) return 'img';
    if (['txt', 'log', 'json', 'xml', 'md', 'ini', 'html', 'htm'].includes(e) || mime.startsWith('text/')) return 'txt';
    return 'unknown';
  }
  function iconClass(kind) {
    return { pdf: 'pdf', docx: 'doc', doc: 'doc', xlsx: 'xls', pptx: 'ppt', ppt: 'ppt', img: 'img' }[kind] || 'txt';
  }
  function iconLabel(name) { return (extOf(name) || '?').slice(0, 4).toUpperCase(); }
  function fmtSize(b) {
    if (b == null || b < 0) return '';
    if (b < 1024) return b + ' B';
    if (b < 1048576) return (b / 1024).toFixed(0) + ' KB';
    return (b / 1048576).toFixed(1) + ' MB';
  }
  function fmtTime(t) {
    const d = new Date(t), now = new Date();
    const hm = d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
    if (d.toDateString() === now.toDateString()) return 'Hôm nay ' + hm;
    return d.toLocaleDateString('vi-VN') + ' ' + hm;
  }
  function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
  function toast(msg) { if (native) native.toast(msg); else console.log(msg); }
  function loading(on, text) { $('loading').classList.toggle('hidden', !on); if (text) $('loadingText').textContent = text; }
  const contentWidth = () => Math.max(200, document.documentElement.clientWidth - 16);

  // ---------- Màn hình chính ----------
  function show(screen) {
    $('home').classList.toggle('hidden', screen !== 'home');
    $('viewer').classList.toggle('hidden', screen !== 'viewer');
    window.scrollTo(0, 0);
  }
  function getRecents() {
    try { return JSON.parse(native ? native.getRecents() : (localStorage.getItem('recents') || '[]')); }
    catch (e) { return []; }
  }
  function renderRecents() {
    const list = getRecents();
    const ul = $('recent');
    ul.innerHTML = '';
    $('emptyRecent').classList.toggle('hidden', list.length > 0);
    $('btnClear').classList.toggle('hidden', list.length === 0);
    list.forEach((r) => {
      const li = document.createElement('li');
      const k = kindOf(r.name, r.mime);
      li.innerHTML = `<div class="ficon ${iconClass(k)}">${esc(iconLabel(r.name))}</div>
        <div class="finfo"><div class="fname">${esc(r.name)}</div>
        <div class="fmeta">${esc(fmtTime(r.time))}${r.size > 0 ? ' · ' + fmtSize(r.size) : ''}</div></div>
        <button class="rm" aria-label="Xoá">×</button>`;
      li.addEventListener('click', (ev) => {
        if (ev.target.classList.contains('rm')) {
          ev.stopPropagation();
          if (native) native.removeRecent(r.uri);
          renderRecents();
          return;
        }
        if (native) native.openRecent(r.uri); else toast('Chỉ mở lại được trong app');
      });
      ul.appendChild(li);
    });
  }

  $('btnOpen').addEventListener('click', () => {
    if (native) native.pickFile(); else $('fileInput').click();
  });
  $('fileInput').addEventListener('change', (e) => {
    const f = e.target.files[0];
    if (!f) return;
    App.onFile({ name: f.name, mime: f.type, size: f.size, blob: f });
    e.target.value = '';
  });
  $('btnClear').addEventListener('click', () => {
    if (confirm('Xoá toàn bộ lịch sử file gần đây?')) { if (native) native.clearRecents(); renderRecents(); }
  });
  $('btnBack').addEventListener('click', () => App.back());
  $('btnShare').addEventListener('click', async () => {
    if (native) { native.share(); return; }
    if (current && current.blob && navigator.canShare) {
      const file = new File([current.blob], current.name, { type: current.mime || 'application/octet-stream' });
      if (navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file] }); } catch (e) {} }
    }
  });
  $('btnOpenWith').addEventListener('click', () => { if (native) native.openWith(); else toast('Chỉ có trong app'); });

  // ---------- Mở & render ----------
  async function getBuffer(doc) {
    if (doc.blob) return await doc.blob.arrayBuffer();
    const res = await fetch(doc.url);
    if (!res.ok) throw new Error('Không đọc được file (' + res.status + ')');
    return await res.arrayBuffer();
  }

  function resetViewer() {
    renderToken++;
    if (pdfObserver) { pdfObserver.disconnect(); pdfObserver = null; }
    $('content').innerHTML = '';
    $('content').className = 'content';
    $('sheetTabs').classList.add('hidden');
    $('sheetTabs').innerHTML = '';
    $('pageBadge').classList.add('hidden');
    document.body.classList.remove('has-tabs', 'has-doctools');
    const wbtn = document.getElementById('wrapBtn'); if (wbtn) wbtn.remove();
    $('docTools').classList.add('hidden');
    $('sheetMask').classList.add('hidden');
    $('pickMask').classList.add('hidden');
    Zoom.detach();
    window.onscroll = null;
  }

  async function openDoc(doc) {
    current = doc;
    resetViewer();
    const token = renderToken;
    $('docName').textContent = doc.name;
    show('viewer');
    const kind = kindOf(doc.name, doc.mime);
    loading(true, 'Đang mở…');
    try {
      const buf = await getBuffer(doc);
      if (token !== renderToken) return;
      switch (kind) {
        case 'pdf': await renderPdf(buf, token); break;
        case 'docx': await renderDocx(buf, token); break;
        case 'xlsx': await renderXlsx(buf, doc.name); break;
        case 'pptx': await renderPptx(buf, token); break;
        case 'img': renderImg(buf, doc); break;
        case 'txt': renderTxt(buf); break;
        case 'doc': case 'ppt':
          showMsg('Định dạng cũ (.' + extOf(doc.name) + ')',
            'App chỉ xem được định dạng mới (.docx / .pptx). Bạn vẫn có thể chia sẻ hoặc mở bằng app khác (Word, PowerPoint, WPS…).', true);
          break;
        default:
          if (await sniffPdf(buf)) { await renderPdf(buf, token); break; }
          if (sniffZip(buf)) { await renderZipGuess(buf, token, doc.name); break; }
          showMsg('Chưa hỗ trợ loại file này', 'Bạn có thể chia sẻ hoặc mở bằng app khác.', true);
      }
    } catch (err) {
      console.error(err);
      if (token === renderToken) showMsg('Không mở được file', (err && (err.message || err.name)) ? `${err.name || 'Lỗi'}: ${err.message}` : String(err), true);
    } finally {
      if (token === renderToken) loading(false);
    }
  }

  function showMsg(title, text, withOpenWith) {
    $('content').innerHTML = `<div class="msg"><h3>${esc(title)}</h3><div>${esc(text)}</div>
      ${withOpenWith && native ? '<button id="msgOpenWith">Mở bằng app khác</button>' : ''}</div>`;
    const b = $('msgOpenWith');
    if (b) b.addEventListener('click', () => native.openWith());
  }

  async function sniffPdf(buf) {
    const h = new Uint8Array(buf.slice(0, 5));
    return String.fromCharCode(...h) === '%PDF-';
  }
  function sniffZip(buf) {
    const h = new Uint8Array(buf.slice(0, 2));
    return h[0] === 0x50 && h[1] === 0x4b;
  }
  // File không rõ đuôi (vd. Zalo đổi tên) -> đoán theo nội dung zip
  async function renderZipGuess(buf, token, name) {
    const zip = await JSZip.loadAsync(buf);
    if (zip.file('word/document.xml')) return renderDocx(buf, token);
    if (zip.file('ppt/presentation.xml')) return renderPptx(buf, token);
    if (zip.file('xl/workbook.xml')) return await renderXlsx(buf, name);
    showMsg('Chưa hỗ trợ loại file này', 'Bạn có thể chia sẻ hoặc mở bằng app khác.', true);
  }

  // ----- PDF -----
  async function renderPdf(buf, token) {
    const pdf = await pdfjsLib.getDocument({
      data: new Uint8Array(buf),
      cMapUrl: 'lib/cmaps/', cMapPacked: true,
      standardFontDataUrl: 'lib/standard_fonts/',
    }).promise;
    if (token !== renderToken) return;
    const W = contentWidth();
    const { sizer, inner } = Zoom.wrap();
    $('content').appendChild(sizer);
    const first = await pdf.getPage(1);
    const vp1 = first.getViewport({ scale: 1 });
    const pages = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const div = document.createElement('div');
      div.className = 'pdf-page';
      div.dataset.page = i;
      div.style.width = W + 'px';
      div.style.height = Math.round(W * vp1.height / vp1.width) + 'px';
      inner.appendChild(div);
      pages.push(div);
    }
    loading(false);
    const badge = $('pageBadge');
    badge.classList.remove('hidden');
    badge.textContent = '1 / ' + pdf.numPages;

    let level = 1;                 // mức zoom hiện tại (1 = vừa màn hình)
    const done = new Map();        // số trang -> độ nét đã vẽ
    const dpr = window.devicePixelRatio || 1;
    const wantRatio = () => Math.min(dpr * 1.5 * Math.max(1, level), 3000 / W);
    const renderPage = async (div) => {
      const n = +div.dataset.page;
      const ratio = wantRatio();
      if (done.get(n) >= ratio * 0.95) return;
      done.set(n, ratio);
      const page = n === 1 ? first : await pdf.getPage(n);
      if (token !== renderToken) return;
      const vp = page.getViewport({ scale: 1 });
      div.style.height = Math.round(W * vp.height / vp.width) + 'px';
      const v = page.getViewport({ scale: (W / vp.width) * ratio });
      const canvas = document.createElement('canvas');
      canvas.width = Math.floor(v.width);
      canvas.height = Math.floor(v.height);
      await page.render({ canvasContext: canvas.getContext('2d'), viewport: v }).promise;
      if (token !== renderToken) return;
      div.replaceChildren(canvas);   // thay sau khi vẽ xong -> không nháy trắng
    };
    const nearView = (div) => { const r = div.getBoundingClientRect(); return r.bottom > -800 && r.top < window.innerHeight + 800; };
    pdfObserver = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) renderPage(en.target); });
    }, { rootMargin: '1200px 600px' });
    pages.forEach((p) => pdfObserver.observe(p));

    Zoom.attach({
      inner, sizer, fit: 1,
      onChange: (lv) => { level = lv; pages.filter(nearView).forEach(renderPage); },
    });

    window.onscroll = () => {
      const y = window.innerHeight / 3;
      let cur = 1;
      for (const p of pages) { if (p.getBoundingClientRect().top <= y) cur = +p.dataset.page; else break; }
      badge.textContent = cur + ' / ' + pdf.numPages;
      if (level > 1) pages.filter(nearView).forEach(renderPage);
    };
  }

  // ----- Word -----
  async function renderDocx(buf, token) {
    const host = document.createElement('div');
    host.className = 'docx-host';
    const { sizer, inner } = Zoom.wrap(host);
    $('content').appendChild(sizer);
    await docx.renderAsync(buf, host, null, {
      inWrapper: true, ignoreWidth: false, ignoreHeight: false, breakPages: true,
      renderHeaders: true, renderFooters: true, renderFootnotes: true, useBase64URL: true,
      experimental: true, renderComments: true, renderChanges: true,
    });
    if (token !== renderToken) return;
    setupMarkup(host);
    // Thu nhỏ trang A4 vừa màn hình điện thoại
    const pageW = Math.max(host.offsetWidth, 1);
    Zoom.attach({ inner, sizer, fit: Math.min(1, contentWidth() / pageW) });
  }

  // ----- Đổi tên file (tên dùng khi chia sẻ) -----
  $('docName').addEventListener('click', () => {
    if (!current) return;
    const inp = $('renameInput');
    inp.value = current.name;
    $('renameMask').classList.remove('hidden');
    setTimeout(() => {
      inp.focus();
      const dot = current.name.lastIndexOf('.');
      inp.setSelectionRange(0, dot > 0 ? dot : current.name.length);   // chọn phần tên, giữ đuôi
    }, 50);
  });
  const closeRename = () => $('renameMask').classList.add('hidden');
  const doRename = () => {
    const v = $('renameInput').value.trim();
    if (v && current) {
      let name = native ? native.rename(v) : v;
      if (!native) {
        const ext = (current.name.match(/\.[^.]+$/) || [''])[0];
        if (ext && !name.toLowerCase().endsWith(ext.toLowerCase())) name += ext;
      }
      if (name) { current.name = name; $('docName').textContent = name; toast('Đã đổi tên'); }
    }
    closeRename();
  };
  $('renameOk').addEventListener('click', doRename);
  $('renameCancel').addEventListener('click', closeRename);
  $('renameInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') doRename(); });
  $('renameMask').addEventListener('click', (e) => { if (e.target === $('renameMask')) closeRename(); });

  // ----- Markup (track changes) & bình luận trong Word -----
  let markup = { host: null, comments: [], changes: [], tab: 'c' };
  function getMode() { try { return localStorage.getItem('markupMode') || 'all'; } catch (e) { return 'all'; } }
  function setMode(m) {
    try { localStorage.setItem('markupMode', m); } catch (e) {}
    if (!markup.host) return;
    markup.host.classList.remove('mode-all', 'mode-final', 'mode-original');
    markup.host.classList.add('mode-' + m);
    $('markupSeg').querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.m === m));
  }
  function fmtDate(d) {
    if (!d) return '';
    const t = new Date(d);
    return isNaN(t) ? d : t.toLocaleString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  }
  function setupMarkup(host) {
    markup = { host, comments: [], changes: [], tab: 'c' };
    host.querySelectorAll('.docx-comment-ref').forEach((ref) => {
      const pop = ref.nextElementSibling;
      if (!pop || !pop.classList.contains('docx-comment-popover')) return;
      const author = pop.querySelector('.docx-comment-author')?.textContent || '';
      const body = document.createElement('div');
      Array.from(pop.children).forEach((ch) => {
        if (!ch.classList.contains('docx-comment-author') && !ch.classList.contains('docx-comment-date')) body.appendChild(ch.cloneNode(true));
      });
      // đoạn văn được bình luận (văn bản ngay trước biểu tượng)
      let quote = '';
      const para = ref.closest('p');
      if (para) {
        const r = document.createRange();
        r.setStart(para, 0);
        r.setEndBefore(ref);
        quote = r.toString().trim().slice(-60);
      }
      const i = markup.comments.length;
      markup.comments.push({ el: ref, author, html: body.innerHTML, text: body.textContent.trim(), quote });
      ref.title = author;
      ref.addEventListener('click', (e) => { e.stopPropagation(); openSheet('c', i); });
    });
    host.querySelectorAll('ins, del').forEach((el) => {
      const text = el.textContent;
      if (!text.trim()) return;
      markup.changes.push({ el, type: el.tagName.toLowerCase(), author: el.title || '', date: el.getAttribute('datetime') || el.dateTime || '', text });
    });
    const nC = markup.comments.length, nR = markup.changes.length;
    if (!nC && !nR) return;
    $('docTools').classList.remove('hidden');
    document.body.classList.add('has-doctools');
    $('cmtCount').textContent = nC + nR;
    setMode(getMode());
  }
  function openSheet(tab, focusIdx) {
    markup.tab = tab;
    const tabs = $('sheetTabs2').querySelectorAll('button');
    tabs[0].textContent = `Bình luận (${markup.comments.length})`;
    tabs[1].textContent = `Chỉnh sửa (${markup.changes.length})`;
    tabs.forEach((b) => b.classList.toggle('on', b.dataset.t === tab));
    const body = $('sheetBody');
    const list = tab === 'c' ? markup.comments : markup.changes;
    if (!list.length) body.innerHTML = `<div class="empty-s">${tab === 'c' ? 'Không có bình luận' : 'Không có chỉnh sửa (track changes)'}</div>`;
    else body.innerHTML = list.map((x, i) => tab === 'c'
      ? `<div class="item" data-i="${i}"><div class="who"><b>${esc(x.author || 'Ẩn danh')}</b><span>#${i + 1}</span></div>
           ${x.quote ? `<div class="quote">…${esc(x.quote)}</div>` : ''}<div class="txt">${x.html || esc(x.text)}</div></div>`
      : `<div class="item" data-i="${i}"><div class="who"><span><span class="tag ${x.type}">${x.type === 'ins' ? 'Thêm' : 'Xoá'}</span><b>${esc(x.author || 'Ẩn danh')}</b></span><span>${esc(fmtDate(x.date))}</span></div>
           <div class="txt"><span class="chg ${x.type}">${esc(x.text.length > 200 ? x.text.slice(0, 200) + '…' : x.text)}</span></div></div>`).join('');
    body.querySelectorAll('.item').forEach((it) => it.addEventListener('click', () => goTo(list[+it.dataset.i].el)));
    $('sheetMask').classList.remove('hidden');
    if (focusIdx != null) {
      const it = body.querySelector(`.item[data-i="${focusIdx}"]`);
      if (it) { it.scrollIntoView({ block: 'center' }); it.classList.add('flash'); }
    }
  }
  function goTo(el) {
    $('sheetMask').classList.add('hidden');
    if (getMode() !== 'all') setMode('all');   // phải hiện markup mới thấy vị trí
    el.scrollIntoView({ block: 'center', inline: 'center' });
    el.classList.remove('flash');
    void el.offsetWidth;
    el.classList.add('flash');
  }
  $('markupSeg').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) setMode(b.dataset.m); });
  $('btnComments').addEventListener('click', () => openSheet(markup.comments.length ? 'c' : 'r'));
  $('sheetTabs2').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) openSheet(b.dataset.t); });
  $('pickMask').addEventListener('click', (e) => { if (e.target === $('pickMask') || e.target.closest('.sheet-close')) $('pickMask').classList.add('hidden'); });
  $('sheetMask').addEventListener('click', (e) => { if (e.target === $('sheetMask') || e.target.closest('.sheet-close')) $('sheetMask').classList.add('hidden'); });

  // ----- Excel -----
  function colName(n) { let s = ''; n++; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; }
  // Font Office -> font kèm theo app có cùng kích thước chữ
  function xlFont(name) {
    if (!name) return null;
    const n = name.toLowerCase();
    if (n.startsWith('calibri') || n.startsWith('aptos')) return '"XL-Calibri", Calibri, sans-serif';
    if (n.includes('times') || n.startsWith('cambria') || n.includes('serif') || n.startsWith('vn') || n.startsWith('.vn')) return '"XL-Times", "Times New Roman", serif';
    if (n.startsWith('arial') || n.startsWith('tahoma') || n.startsWith('helvetica') || n.startsWith('verdana') || n.startsWith('segoe')) return '"XL-Arial", Arial, sans-serif';
    return null;
  }
  let wrapAll = (() => { try { return localStorage.getItem('xlWrapAll') === '1'; } catch (e) { return false; } })();

  async function renderXlsx(buf, name) {
    const isCsv = /\.(csv|tsv)$/i.test(name);
    let wb, styles = null;
    if (isCsv) {
      let text = new TextDecoder('utf-8').decode(buf);
      wb = XLSX.read(text, { type: 'string', raw: false, FS: /\.tsv$/i.test(name) ? '\t' : undefined });
    } else {
      wb = XLSX.read(new Uint8Array(buf), { type: 'array', cellDates: true, cellStyles: true, dense: false });
      if (sniffZip(buf)) { try { styles = await XlsxStyle.load(buf); } catch (e) { console.warn('styles', e); } }
    }
    const host = $('content');
    host.className = 'content flush';
    const tabs = $('sheetTabs');
    const MAX_ROWS = 5000, MAX_COLS = 200;
    const DEF_COL = 64, DEF_ROW = 20;   // kích thước mặc định của Excel (px)

    // Độ rộng cột theo file gốc: Excel ~ 7px mỗi ký tự + 5px lề
    const colPx = (ws, c) => {
      const ci = (ws['!cols'] || [])[c];
      if (!ci) return ws['!defcolw'] ? Math.round(ws['!defcolw'] * 7 + 5) : DEF_COL;
      if (ci.hidden) return 0;
      if (ci.width != null) return Math.round(ci.width * 7 + 5);
      if (ci.wch != null) return Math.round(ci.wch * 7 + 5);
      return ci.wpx || DEF_COL;
    };
    const rowPx = (ws, r) => {
      const ri = (ws['!rows'] || [])[r];
      if (!ri) return DEF_ROW;
      if (ri.hidden) return 0;
      if (ri.hpt != null) return Math.round(ri.hpt * 4 / 3);
      return ri.hpx || DEF_ROW;
    };

    const showSheet = async (idx) => {
      const sheetName = wb.SheetNames[idx];
      const ws = wb.Sheets[sheetName];
      host.innerHTML = '';
      curSheet = idx;
      tabs.querySelectorAll('.st-scroll button').forEach((b, i) => {
        b.classList.toggle('on', i === idx);
        if (i === idx) b.scrollIntoView({ inline: 'center', block: 'nearest' });
      });
      const prev = tabs.querySelector('.st-prev'), next = tabs.querySelector('.st-next');
      if (prev) { prev.disabled = idx === 0; next.disabled = idx === wb.SheetNames.length - 1; }
      Zoom.detach();
      if (!ws || !ws['!ref']) { host.innerHTML = '<div class="msg">Sheet trống</div>'; return; }
      const st = styles ? await styles.sheetStyles(sheetName) : { map: {}, gridLines: true };
      const range = XLSX.utils.decode_range(ws['!ref']);
      range.s.r = 0; range.s.c = 0;   // luôn bắt đầu từ A1 như Excel
      let note = '';
      if (range.e.r - range.s.r + 1 > MAX_ROWS) { range.e.r = range.s.r + MAX_ROWS - 1; note = `Chỉ hiển thị ${MAX_ROWS} dòng đầu.`; }
      if (range.e.c - range.s.c + 1 > MAX_COLS) { range.e.c = range.s.c + MAX_COLS - 1; note += ` Chỉ hiển thị ${MAX_COLS} cột đầu.`; }
      // gộp ô
      const merges = ws['!merges'] || [];
      const skip = new Set(), spanAt = {};
      merges.forEach((m) => {
        spanAt[m.s.r + ':' + m.s.c] = { rs: m.e.r - m.s.r + 1, cs: m.e.c - m.s.c + 1 };
        for (let r = m.s.r; r <= m.e.r; r++) for (let c = m.s.c; c <= m.e.c; c++) if (r !== m.s.r || c !== m.s.c) skip.add(r + ':' + c);
      });
      const widths = [];
      let total = 40;
      for (let c = range.s.c; c <= range.e.c; c++) { widths.push(colPx(ws, c)); total += widths[widths.length - 1]; }
      const hasVal = (r, c) => { const x = ws[XLSX.utils.encode_cell({ r, c })]; return x && x.v != null && x.v !== ''; };

      const df = styles && styles.defaultFont;
      const dfFam = (df && xlFont(df.name)) || (isCsv || !styles ? '"XL-Arial", Arial, sans-serif' : '"XL-Calibri", Calibri, sans-serif');
      const dfSize = df && df.sz ? (df.sz * 4 / 3).toFixed(1) + 'px' : (styles ? '14.7px' : '13.3px');
      const parts = [`<table class="xl${st.gridLines ? '' : ' nogrid'}${wrapAll ? ' wrapall' : ''}" style="width:${total}px;font-family:${dfFam.replace(/"/g, "'")};font-size:${dfSize}"><colgroup><col style="width:40px">`];
      widths.forEach((w) => parts.push(`<col style="width:${w}px">`));
      parts.push('</colgroup><thead><tr><th class="corner"></th>');
      for (let c = range.s.c; c <= range.e.c; c++) parts.push(`<th class="ch">${widths[c - range.s.c] ? colName(c) : ''}</th>`);
      parts.push('</tr></thead><tbody>');
      for (let r = range.s.r; r <= range.e.r; r++) {
        const h = rowPx(ws, r);
        if (h === 0) continue;
        parts.push(`<tr style="height:${h}px"><td class="rh">${r + 1}</td>`);
        for (let c = range.s.c; c <= range.e.c; c++) {
          const key = r + ':' + c;
          if (skip.has(key)) continue;
          const addr = XLSX.utils.encode_cell({ r, c });
          const cell = ws[addr];
          const sp = spanAt[key];
          const attrs = sp ? ` rowspan="${sp.rs}" colspan="${sp.cs}"` : '';
          let v = '';
          const css = [];
          const isNum = cell && (cell.t === 'n' || cell.t === 'd');
          if (cell) v = cell.w != null ? cell.w : (cell.v instanceof Date ? cell.v.toLocaleDateString('vi-VN') : (cell.v != null ? String(cell.v) : (cell.f ? '=' + cell.f : '')));
          const xf = styles && st.map[addr] != null ? styles.xfs[st.map[addr]] : null;
          let wrap = false;
          if (xf) {
            wrap = xf.wrap;
            if (xf.h && xf.h !== 'general') css.push('text-align:' + ({ center: 'center', centerContinuous: 'center', right: 'right', left: 'left', justify: 'justify', fill: 'left', distributed: 'center' }[xf.h] || 'left'));
            else if (isNum) css.push('text-align:right');
            css.push('vertical-align:' + ({ top: 'top', center: 'middle', bottom: 'bottom', justify: 'top', distributed: 'middle' }[xf.v] || 'bottom'));
            if (xf.indent) css.push(`padding-left:${4 + xf.indent * 9}px`);
            const f = xf.font;
            if (f) {
              if (f.b) css.push('font-weight:700');
              if (f.i) css.push('font-style:italic');
              if (f.u || f.strike) css.push('text-decoration:' + [f.u ? 'underline' : '', f.strike ? 'line-through' : ''].join(' ').trim());
              if (f.sz) css.push(`font-size:${(f.sz * 4 / 3).toFixed(1)}px`);
              const fam = xlFont(f.name);
              if (fam && (!df || f.name !== df.name)) css.push('font-family:' + fam.replace(/"/g, "'"));
              if (f.color && f.color.toLowerCase() !== '#000000') css.push('color:' + f.color);
            }
            if (xf.fill) css.push('background:' + xf.fill);
            const b = xf.border;
            if (b) { if (b.l) css.push('border-left:' + b.l); if (b.r) css.push('border-right:' + b.r); if (b.t) css.push('border-top:' + b.t); if (b.b) css.push('border-bottom:' + b.b); }
          } else {
            css.push('vertical-align:bottom');
            if (isNum) css.push('text-align:right');
          }
          let cls = wrap ? 'w' : '';
          // chữ không xuống dòng tràn sang ô trống bên phải (giống Excel)
          if (!wrap && v && !isNum && !sp && c < range.e.c && !hasVal(r, c + 1) && !skip.has(r + ':' + (c + 1))) cls += ' spill';
          parts.push(`<td${attrs}${cls ? ` class="${cls.trim()}"` : ''}${css.length ? ` style="${css.join(';')}"` : ''}>${esc(v)}</td>`);
        }
        parts.push('</tr>');
      }
      parts.push('</tbody></table>');
      host.innerHTML = (note ? `<div class="note">${esc(note.trim())}</div>` : '') +
        `<div class="sheet-wrap" style="height:calc(100vh - var(--bar-h) - ${wb.SheetNames.length > 1 ? 52 : 0}px${note ? ' - 30px' : ''})"></div>`;
      const scroller = host.querySelector('.sheet-wrap');
      const { sizer, inner } = Zoom.wrap();
      sizer.style.margin = '0';
      inner.innerHTML = parts.join('');
      scroller.appendChild(sizer);
      // Bảng rộng hơn màn hình -> mở ở chế độ vừa chiều ngang (tối thiểu 35%)
      const fit = Math.max(0.35, Math.min(1, scroller.clientWidth / Math.max(1, inner.offsetWidth)));
      Zoom.attach({ inner, sizer, scroller, fit });
      // Nút "Hiện đủ chữ": cho mọi ô tự xuống dòng
      let wb2 = document.getElementById('wrapBtn');
      if (!wb2) { wb2 = document.createElement('button'); wb2.id = 'wrapBtn'; wb2.className = 'wrap-btn'; document.getElementById('viewer').appendChild(wb2); }
      const paint = () => { wb2.textContent = wrapAll ? '↵ Đang hiện đủ chữ' : '↵ Hiện đủ chữ'; wb2.classList.toggle('on', wrapAll); };
      paint();
      wb2.onclick = () => {
        wrapAll = !wrapAll;
        try { localStorage.setItem('xlWrapAll', wrapAll ? '1' : '0'); } catch (e) {}
        inner.querySelector('table').classList.toggle('wrapall', wrapAll);
        paint();
      };
      window.scrollTo(0, 0);
    };

    let curSheet = 0;
    if (wb.SheetNames.length > 1) {
      tabs.classList.remove('hidden');
      document.body.classList.add('has-tabs');
      tabs.innerHTML = `<button class="st-btn st-menu" aria-label="Danh sách sheet">☰</button>
        <div class="st-scroll"></div>
        <button class="st-btn st-prev" aria-label="Sheet trước">‹</button>
        <button class="st-btn st-next" aria-label="Sheet sau">›</button>`;
      const scroll = tabs.querySelector('.st-scroll');
      wb.SheetNames.forEach((n, i) => {
        const b = document.createElement('button');
        b.textContent = n;
        b.onclick = () => showSheet(i);
        scroll.appendChild(b);
      });
      tabs.querySelector('.st-prev').onclick = () => curSheet > 0 && showSheet(curSheet - 1);
      tabs.querySelector('.st-next').onclick = () => curSheet < wb.SheetNames.length - 1 && showSheet(curSheet + 1);
      tabs.querySelector('.st-menu').onclick = () => {
        $('pickTitle').textContent = `Chọn sheet (${wb.SheetNames.length})`;
        $('pickBody').innerHTML = wb.SheetNames.map((n, i) =>
          `<div class="pick-item${i === curSheet ? ' on' : ''}" data-i="${i}"><span class="num">${i + 1}</span><span>${esc(n)}</span></div>`).join('');
        $('pickBody').querySelectorAll('.pick-item').forEach((it) => it.onclick = () => { $('pickMask').classList.add('hidden'); showSheet(+it.dataset.i); });
        $('pickMask').classList.remove('hidden');
        const on = $('pickBody').querySelector('.on'); if (on) on.scrollIntoView({ block: 'center' });
      };
    }
    await showSheet(0);
  }

  // ----- PowerPoint -----
  async function renderPptx(buf, token) {
    const W = contentWidth();
    const { sizer, inner } = Zoom.wrap();
    $('content').appendChild(sizer);
    const info = await PptxRender.render(buf, inner, {
      width: W,
      isCancelled: () => token !== renderToken,
      onProgress: (i, n) => loading(true, `Đang dựng slide ${i}/${n}…`),
    });
    if (!info || token !== renderToken) return;
    Zoom.attach({ inner, sizer, fit: W / info.slideWidth });
  }

  // ----- Ảnh & text -----
  function renderImg(buf, doc) {
    const url = URL.createObjectURL(new Blob([buf], { type: doc.mime || 'image/*' }));
    const img = new Image();
    img.src = url;
    img.style.display = 'block';
    const { sizer, inner } = Zoom.wrap(img);
    $('content').appendChild(sizer);
    img.onload = () => {
      img.style.width = img.naturalWidth + 'px';
      Zoom.attach({ inner, sizer, fit: Math.min(1, contentWidth() / img.naturalWidth) });
    };
  }
  function renderTxt(buf) {
    let text = new TextDecoder('utf-8').decode(buf);
    if (text.length > 2000000) text = text.slice(0, 2000000) + '\n…(đã cắt bớt)';
    const pre = document.createElement('pre');
    pre.className = 'txt';
    pre.textContent = text;
    $('content').appendChild(pre);
  }

  // ---------- API cho Kotlin gọi ----------
  window.App = {
    onFile(doc) { openDoc(doc); },
    back() {
      if (!$('sheetMask').classList.contains('hidden')) { $('sheetMask').classList.add('hidden'); return true; }
      if (!$('pickMask').classList.contains('hidden')) { $('pickMask').classList.add('hidden'); return true; }
      if (!$('renameMask').classList.contains('hidden')) { closeRename(); return true; }
      if (!$('viewer').classList.contains('hidden')) {
        resetViewer(); current = null; renderRecents(); show('home');
        return true;
      }
      return false;
    },
    refreshRecents() { renderRecents(); },
    setLoading(on, text) { loading(on, text); },
  };

  renderRecents();
  show('home');
  if (native) native.ready();
})();
