/* Zoom - phóng to / thu nhỏ tài liệu bằng 2 ngón tay, chạm đúp, hoặc nút +/-.
   Cấu trúc: scroller > .zoom-sizer (kích thước đã nhân tỉ lệ) > .zoom-inner (transform: scale)
   Chạy được trên mọi trình duyệt/WebView, không phụ thuộc CSS zoom. */
(function () {
  'use strict';
  let st = null; // trạng thái của tài liệu đang xem

  function wrap(content) {
    const sizer = document.createElement('div');
    sizer.className = 'zoom-sizer';
    const inner = document.createElement('div');
    inner.className = 'zoom-inner';
    sizer.appendChild(inner);
    if (content) inner.appendChild(content);
    return { sizer, inner };
  }

  /**
   * opts: { inner, sizer, scroller (null = window), fit (tỉ lệ vừa màn hình), onChange(z) }
   */
  function attach(opts) {
    detach();
    st = {
      inner: opts.inner, sizer: opts.sizer, scroller: opts.scroller || null,
      fit: opts.fit || 1, z: opts.fit || 1, onChange: opts.onChange || null,
      timer: null,
    };
    st.min = st.fit * 0.5;
    st.max = st.fit * 5;
    st.ro = new ResizeObserver(() => applySize());
    st.ro.observe(st.inner);
    apply(st.z);
    showCtl(true);
  }

  function detach() {
    if (st) { st.ro.disconnect(); clearTimeout(st.timer); }
    st = null;
    showCtl(false);
  }

  function applySize() {
    if (!st) return;
    st.sizer.style.width = st.inner.offsetWidth * st.z + 'px';
    st.sizer.style.height = st.inner.offsetHeight * st.z + 'px';
  }

  function apply(z) {
    st.z = z;
    st.inner.style.transform = `scale(${z})`;
    applySize();
    const pct = document.getElementById('zoomPct');
    if (pct) pct.textContent = Math.round((z / st.fit) * 100) + '%';
    if (st.onChange) {
      clearTimeout(st.timer);
      st.timer = setTimeout(() => st && st.onChange && st.onChange(st.z / st.fit), 250);
    }
  }

  function scrollBy(dx, dy) {
    if (!st.scroller) window.scrollBy(dx, dy);
    else { st.scroller.scrollLeft += dx; st.scroller.scrollTop += dy; }
  }
  const clamp = (v) => Math.max(st.min, Math.min(st.max, v));

  // Đặt tỉ lệ mới, giữ điểm (cx, cy) trên màn hình đứng yên. anchor = toạ độ điểm trong tài liệu (chưa nhân)
  function zoomAt(z, cx, cy, anchor) {
    if (!st) return;
    z = clamp(z);
    if (!anchor) {
      const r = st.inner.getBoundingClientRect();
      anchor = { x: (cx - r.left) / st.z, y: (cy - r.top) / st.z };
    }
    apply(z);
    const r2 = st.inner.getBoundingClientRect();
    scrollBy(r2.left + anchor.x * z - cx, r2.top + anchor.y * z - cy);
  }

  function viewCenter() {
    if (!st.scroller) {
      const bar = 52;
      return { x: window.innerWidth / 2, y: bar + (window.innerHeight - bar) / 2 };
    }
    const r = st.scroller.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }

  // ---- Cảm ứng ----
  let pinch = null, lastTap = 0, tapPos = null, moved = false;
  const dist = (a, b) => Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
  const mid = (a, b) => ({ x: (a.clientX + b.clientX) / 2, y: (a.clientY + b.clientY) / 2 });

  document.addEventListener('touchstart', (e) => {
    if (!st) return;
    if (e.touches.length === 2) {
      const m = mid(e.touches[0], e.touches[1]);
      const r = st.inner.getBoundingClientRect();
      pinch = { d0: dist(e.touches[0], e.touches[1]), z0: st.z, anchor: { x: (m.x - r.left) / st.z, y: (m.y - r.top) / st.z } };
      e.preventDefault();
    } else if (e.touches.length === 1) {
      moved = false;
      tapPos = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
  }, { passive: false });

  document.addEventListener('touchmove', (e) => {
    if (!st) return;
    if (pinch && e.touches.length === 2) {
      e.preventDefault();
      const m = mid(e.touches[0], e.touches[1]);
      const z = pinch.z0 * dist(e.touches[0], e.touches[1]) / pinch.d0;
      zoomAt(z, m.x, m.y, pinch.anchor);
    } else if (tapPos && e.touches.length === 1) {
      if (Math.hypot(e.touches[0].clientX - tapPos.x, e.touches[0].clientY - tapPos.y) > 10) moved = true;
    }
  }, { passive: false });

  document.addEventListener('touchend', (e) => {
    if (!st) return;
    if (pinch && e.touches.length < 2) { pinch = null; lastTap = 0; return; }
    if (e.touches.length === 0 && tapPos && !moved && !e.target.closest('button, .bar, .sheet-tabs, .zoom-ctl')) {
      const now = Date.now();
      if (now - lastTap < 300) {
        // chạm đúp: vừa màn hình <-> phóng 2.5 lần
        const target = st.z > st.fit * 1.2 ? st.fit : st.fit * 2.5;
        zoomAt(target, tapPos.x, tapPos.y);
        lastTap = 0;
        e.preventDefault();
      } else lastTap = now;
    }
  }, { passive: false });

  // Chặn pinch-zoom của trình duyệt Safari
  document.addEventListener('gesturestart', (e) => e.preventDefault());

  // Ctrl + lăn chuột trên máy tính
  document.addEventListener('wheel', (e) => {
    if (!st || !e.ctrlKey) return;
    e.preventDefault();
    zoomAt(st.z * (e.deltaY < 0 ? 1.1 : 1 / 1.1), e.clientX, e.clientY);
  }, { passive: false });

  // ---- Nút +/- ----
  function showCtl(on) {
    const c = document.getElementById('zoomCtl');
    if (c) c.classList.toggle('hidden', !on);
  }
  document.addEventListener('DOMContentLoaded', () => {
    const c = document.getElementById('zoomCtl');
    if (!c) return;
    c.querySelector('.zin').addEventListener('click', () => { const p = viewCenter(); zoomAt(st.z * 1.25, p.x, p.y); });
    c.querySelector('.zout').addEventListener('click', () => { const p = viewCenter(); zoomAt(st.z / 1.25, p.x, p.y); });
    c.querySelector('#zoomPct').addEventListener('click', () => { const p = viewCenter(); zoomAt(st.fit, p.x, p.y); });
  });

  window.Zoom = { wrap, attach, detach, get level() { return st ? st.z / st.fit : 1; } };
})();
