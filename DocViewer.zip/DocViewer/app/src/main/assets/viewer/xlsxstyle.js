/* XlsxStyle - đọc định dạng ô từ file .xlsx (xuống dòng, căn lề, font, màu nền, viền)
   vì bản SheetJS miễn phí không đọc các thông tin này. */
(function () {
  'use strict';
  const parse = (s) => new DOMParser().parseFromString(s, 'application/xml');
  const kids = (el, n) => (el ? Array.from(el.children).filter((c) => c.localName === n) : []);
  const kid = (el, n) => kids(el, n)[0] || null;
  const attr = (el, n) => (el ? el.getAttribute(n) : null);

  const INDEXED = ['000000', 'FFFFFF', 'FF0000', '00FF00', '0000FF', 'FFFF00', 'FF00FF', '00FFFF', '000000', 'FFFFFF', 'FF0000', '00FF00',
    '0000FF', 'FFFF00', 'FF00FF', '00FFFF', '800000', '008000', '000080', '808000', '800080', '008080', 'C0C0C0', '808080', '9999FF', '993366',
    'FFFFCC', 'CCFFFF', '660066', 'FF8080', '0066CC', 'CCCCFF', '000080', 'FF00FF', 'FFFF00', '00FFFF', '800080', '800000', '008080', '0000FF',
    '00CCFF', 'CCFFFF', 'CCFFCC', 'FFFF99', '99CCFF', 'FF99CC', 'CC99FF', 'FFCC99', '3366FF', '33CCCC', '99CC00', 'FFCC00', 'FF9900', 'FF6600',
    '666699', '969696', '003366', '339966', '003300', '333300', '993300', '993366', '333399', '333333'];

  function applyTint(hex, tint) {
    if (!tint) return hex;
    let [r, g, b] = [0, 2, 4].map((i) => parseInt(hex.substr(i, 2), 16));
    const f = (x) => Math.round(tint < 0 ? x * (1 + tint) : x + (255 - x) * tint);
    return [f(r), f(g), f(b)].map((x) => Math.max(0, Math.min(255, x)).toString(16).padStart(2, '0')).join('');
  }
  function colorOf(el, theme) {
    if (!el) return null;
    let hex = null;
    const rgb = attr(el, 'rgb'), th = attr(el, 'theme'), ix = attr(el, 'indexed');
    if (rgb) hex = rgb.length === 8 ? rgb.slice(2) : rgb;
    else if (th != null) hex = theme[+th];
    else if (ix != null) { if (+ix === 64 || +ix === 65) return null; hex = INDEXED[+ix]; }
    if (!hex) return null;
    return '#' + applyTint(hex, +attr(el, 'tint') || 0);
  }

  async function load(buf) {
    const zip = await JSZip.loadAsync(buf);
    const read = async (p) => { const f = zip.file(p); return f ? f.async('string') : null; };

    // Theme: thứ tự Excel dùng là lt1, dk1, lt2, dk2, accent1..6, hlink, folHlink
    const theme = [];
    const themeXml = await read('xl/theme/theme1.xml');
    if (themeXml) {
      const sc = parse(themeXml).getElementsByTagNameNS('*', 'clrScheme')[0];
      if (sc) {
        const get = (n) => { const e = kid(sc, n); const c = e && (kid(e, 'srgbClr') || kid(e, 'sysClr')); return c ? (attr(c, 'val') && attr(c, 'val').length === 6 ? attr(c, 'val') : attr(c, 'lastClr')) : null; };
        ['lt1', 'dk1', 'lt2', 'dk2', 'accent1', 'accent2', 'accent3', 'accent4', 'accent5', 'accent6', 'hlink', 'folHlink'].forEach((n) => theme.push(get(n)));
      }
    }

    // Styles
    const xfs = [];
    const stylesXml = await read('xl/styles.xml');
    if (stylesXml) {
      const doc = parse(stylesXml).documentElement;
      const fonts = kids(kid(doc, 'fonts'), 'font').map((f) => ({
        b: !!kid(f, 'b') && attr(kid(f, 'b'), 'val') !== '0',
        i: !!kid(f, 'i') && attr(kid(f, 'i'), 'val') !== '0',
        u: !!kid(f, 'u'),
        strike: !!kid(f, 'strike'),
        sz: +attr(kid(f, 'sz'), 'val') || null,
        color: colorOf(kid(f, 'color'), theme),
        name: attr(kid(f, 'name'), 'val'),
      }));
      const fills = kids(kid(doc, 'fills'), 'fill').map((f) => {
        const p = kid(f, 'patternFill');
        if (p && attr(p, 'patternType') && attr(p, 'patternType') !== 'none') return colorOf(kid(p, 'fgColor'), theme) || colorOf(kid(p, 'bgColor'), theme);
        const g = kid(f, 'gradientFill');
        if (g) { const st = kids(g, 'stop')[0]; return st ? colorOf(kid(st, 'color'), theme) : null; }
        return null;
      });
      const borders = kids(kid(doc, 'borders'), 'border').map((b) => {
        const side = (n) => {
          const e = kid(b, n);
          const st = attr(e, 'style');
          if (!st) return null;
          const w = st === 'medium' || st === 'mediumDashed' ? 2 : st === 'thick' || st === 'double' ? 3 : 1;
          const ty = st.includes('dash') || st.includes('Dot') ? 'dashed' : st === 'dotted' || st === 'hair' ? 'dotted' : st === 'double' ? 'double' : 'solid';
          return `${w}px ${ty} ${colorOf(kid(e, 'color'), theme) || '#000'}`;
        };
        return { l: side('left'), r: side('right'), t: side('top'), b: side('bottom') };
      });
      for (const xf of kids(kid(doc, 'cellXfs'), 'xf')) {
        const al = kid(xf, 'alignment');
        xfs.push({
          font: fonts[+attr(xf, 'fontId') || 0] || null,
          fill: fills[+attr(xf, 'fillId') || 0] || null,
          border: borders[+attr(xf, 'borderId') || 0] || null,
          wrap: attr(al, 'wrapText') === '1' || attr(al, 'wrapText') === 'true',
          h: attr(al, 'horizontal'),
          v: attr(al, 'vertical'),
          indent: +attr(al, 'indent') || 0,
        });
      }
    }

    // Đường dẫn từng sheet
    const sheets = {};
    const wbXml = await read('xl/workbook.xml');
    const relXml = await read('xl/_rels/workbook.xml.rels');
    if (wbXml && relXml) {
      const rels = {};
      for (const r of parse(relXml).documentElement.children) rels[attr(r, 'Id')] = attr(r, 'Target');
      const sh = parse(wbXml).getElementsByTagNameNS('*', 'sheet');
      for (const s of sh) {
        const rid = s.getAttribute('r:id') || s.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'id');
        let t = rels[rid];
        if (!t) continue;
        t = t.startsWith('/') ? t.slice(1) : 'xl/' + t.replace(/^\.\//, '');
        sheets[attr(s, 'name')] = t;
      }
    }

    const cache = {};
    // Trả về map "A1" -> chỉ số style, và có hiện lưới hay không
    async function sheetStyles(name) {
      if (cache[name]) return cache[name];
      const p = sheets[name];
      const xml = p ? await read(p) : null;
      const map = {};
      let gridLines = true;
      if (xml) {
        const re = /<(?:\w+:)?c\b([^>]*?)\/?>/g;
        let m;
        while ((m = re.exec(xml))) {
          const a = m[1];
          const r = /\br="([A-Z]+\d+)"/.exec(a), s = /\bs="(\d+)"/.exec(a);
          if (r && s) map[r[1]] = +s[1];
        }
        if (/showGridLines="(0|false)"/.test(xml)) gridLines = false;
      }
      return (cache[name] = { map, gridLines });
    }

    return { xfs, sheetStyles, defaultFont: xfs.length ? (xfs[0].font || null) : null };
  }

  window.XlsxStyle = { load };
})();
