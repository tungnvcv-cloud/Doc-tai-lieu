/* PptxRender - dựng slide .pptx thành HTML (text, hình, ảnh, bảng, nền, theme) */
(function () {
  'use strict';
  const EMU_PX = 9525;              // 1px @96dpi
  const px = (emu) => (+emu || 0) / EMU_PX;
  const PT_PX = 96 / 72;

  // ---- XML helpers (bỏ qua namespace, so theo localName) ----
  const kids = (el, name) => (el ? Array.from(el.children).filter((c) => c.localName === name) : []);
  const kid = (el, name) => (el ? Array.from(el.children).find((c) => c.localName === name) || null : null);
  const path = (el, ...names) => { for (const n of names) { el = kid(el, n); if (!el) return null; } return el; };
  const attr = (el, name) => (el ? el.getAttribute(name) : null);
  const parseXml = (s) => new DOMParser().parseFromString(s, 'application/xml');

  function resolve(base, target) {
    if (target.startsWith('/')) return target.slice(1);
    const parts = base.split('/'); parts.pop();
    for (const seg of target.split('/')) {
      if (seg === '..') parts.pop(); else if (seg !== '.') parts.push(seg);
    }
    return parts.join('/');
  }
  function relsPathOf(p) { const i = p.lastIndexOf('/'); return p.slice(0, i) + '/_rels/' + p.slice(i + 1) + '.rels'; }

  // ---- Màu ----
  function hexToRgb(h) { h = h.replace('#', ''); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; }
  function rgbToHsl([r, g, b]) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b); let h = 0, s = 0; const l = (max + min) / 2;
    if (max !== min) {
      const d = max - min; s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6;
    }
    return [h, s, l];
  }
  function hslToRgb([h, s, l]) {
    if (s === 0) return [l * 255, l * 255, l * 255];
    const f = (p, q, t) => { if (t < 0) t += 1; if (t > 1) t -= 1; if (t < 1 / 6) return p + (q - p) * 6 * t; if (t < 1 / 2) return q; if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6; return p; };
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
    return [f(p, q, h + 1 / 3) * 255, f(p, q, h) * 255, f(p, q, h - 1 / 3) * 255];
  }
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

  // el: phần tử chứa màu (solidFill, fontRef...). trả về css color hoặc null
  function colorOf(el, ctx, phClr) {
    if (!el) return null;
    let c = null, node = null;
    for (const ch of el.children) {
      const n = ch.localName;
      if (n === 'srgbClr') { c = attr(ch, 'val'); node = ch; break; }
      if (n === 'schemeClr') {
        const v = attr(ch, 'val');
        c = v === 'phClr' ? phClr : ctx.theme[ctx.clrMap[v] || v];
        node = ch; break;
      }
      if (n === 'sysClr') { c = attr(ch, 'lastClr') || (attr(ch, 'val') === 'window' ? 'FFFFFF' : '000000'); node = ch; break; }
      if (n === 'prstClr') { c = ({ black: '000000', white: 'FFFFFF', red: 'FF0000', green: '00FF00', blue: '0000FF', yellow: 'FFFF00', gray: '808080' })[attr(ch, 'val')] || '000000'; node = ch; break; }
      if (n === 'scrgbClr') {
        const t = (k) => Math.round(clamp(+attr(ch, k) / 100000, 0, 1) * 255).toString(16).padStart(2, '0');
        c = t('r') + t('g') + t('b'); node = ch; break;
      }
    }
    if (!c) return null;
    let rgb = hexToRgb(c), alpha = 1;
    for (const m of node.children) {
      const v = +attr(m, 'val') / 100000;
      switch (m.localName) {
        case 'lumMod': { const h = rgbToHsl(rgb); h[2] = clamp(h[2] * v, 0, 1); rgb = hslToRgb(h); break; }
        case 'lumOff': { const h = rgbToHsl(rgb); h[2] = clamp(h[2] + v, 0, 1); rgb = hslToRgb(h); break; }
        case 'tint': rgb = rgb.map((x) => x + (255 - x) * (1 - v)); break;
        case 'shade': rgb = rgb.map((x) => x * v); break;
        case 'alpha': alpha = v; break;
        case 'satMod': { const h = rgbToHsl(rgb); h[1] = clamp(h[1] * v, 0, 1); rgb = hslToRgb(h); break; }
      }
    }
    rgb = rgb.map((x) => Math.round(clamp(x, 0, 255)));
    return alpha < 1 ? `rgba(${rgb[0]},${rgb[1]},${rgb[2]},${alpha.toFixed(3)})` : `rgb(${rgb[0]},${rgb[1]},${rgb[2]})`;
  }

  // fill của spPr / bgPr -> {css} ; trả undefined nếu không có định nghĩa fill
  function fillOf(spPr, ctx, phClr) {
    if (!spPr) return undefined;
    if (kid(spPr, 'noFill')) return { none: true };
    const sf = kid(spPr, 'solidFill');
    if (sf) return { color: colorOf(sf, ctx, phClr) };
    const gf = kid(spPr, 'gradFill');
    if (gf) {
      const stops = kids(path(gf, 'gsLst'), 'gs').map((g) => ({ pos: +attr(g, 'pos') / 1000, color: colorOf(g, ctx, phClr) })).filter((s) => s.color);
      if (stops.length) {
        const lin = kid(gf, 'lin');
        const ang = lin ? (+attr(lin, 'ang') / 60000 + 90) : 180;
        return { gradient: `linear-gradient(${ang}deg, ${stops.map((s) => `${s.color} ${s.pos}%`).join(', ')})`, color: stops[0].color };
      }
    }
    const bf = kid(spPr, 'blipFill');
    if (bf) { const b = kid(bf, 'blip'); return { image: attr(b, 'r:embed') || attr(b, 'embed') }; }
    if (kid(spPr, 'grpFill')) return { none: true };
    return undefined;
  }

  // ---- Đọc file pptx ----
  async function load(buf) {
    const zip = await JSZip.loadAsync(buf);
    const cache = {};
    const xml = async (p) => {
      if (cache[p] !== undefined) return cache[p];
      const f = zip.file(p);
      cache[p] = f ? parseXml(await f.async('string')) : null;
      return cache[p];
    };
    const rels = async (p) => {
      const doc = await xml(relsPathOf(p));
      const map = {};
      if (doc) for (const r of doc.documentElement.children) {
        map[attr(r, 'Id')] = { type: (attr(r, 'Type') || '').split('/').pop(), target: attr(r, 'TargetMode') === 'External' ? null : resolve(p, attr(r, 'Target')) };
      }
      return map;
    };
    const blobCache = {};
    const media = async (p) => {
      if (!p) return null;
      if (blobCache[p] !== undefined) return blobCache[p];
      const f = zip.file(p);
      if (!f) return (blobCache[p] = null);
      const ext = p.split('.').pop().toLowerCase();
      const mime = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp', svg: 'image/svg+xml', webp: 'image/webp', tif: 'image/tiff', tiff: 'image/tiff' }[ext];
      if (!mime) return (blobCache[p] = null); // emf/wmf không hiển thị được
      const data = await f.async('uint8array');
      return (blobCache[p] = URL.createObjectURL(new Blob([data], { type: mime })));
    };
    return { zip, xml, rels, media };
  }

  // Thông tin 1 "part" (slide / layout / master)
  async function partInfo(P, p) {
    const doc = await P.xml(p);
    if (!doc || doc.getElementsByTagName('parsererror').length) return null;   // thiếu hoặc hỏng -> bỏ qua
    const rels = await P.rels(p);
    const root = doc.documentElement;
    const cSld = kid(root, 'cSld');
    const spTree = kid(cSld, 'spTree');
    // index placeholder
    const phs = [];
    for (const sp of kids(spTree, 'sp')) {
      const ph = path(sp, 'nvSpPr', 'nvPr', 'ph');
      if (ph) phs.push({ type: attr(ph, 'type') || 'body', idx: attr(ph, 'idx'), sp });
    }
    return { path: p, doc, root, cSld, spTree, rels, phs };
  }

  function findPh(part, type, idx) {
    if (!part) return null;
    if (idx != null) { const m = part.phs.find((x) => x.idx === idx); if (m) return m.sp; }
    const norm = (t) => (t === 'ctrTitle' ? 'title' : t === 'subTitle' ? 'body' : t);
    const m = part.phs.find((x) => x.type === type) || part.phs.find((x) => norm(x.type) === norm(type));
    return m ? m.sp : null;
  }

  // ---- Render ----
  async function render(buf, host, opts) {
    const P = await load(buf);
    const presPath = 'ppt/presentation.xml';
    const presDoc = await P.xml(presPath);
    if (!presDoc) throw new Error('File không phải PowerPoint (.pptx) hợp lệ');
    const pres = presDoc.documentElement;
    const presRels = await P.rels(presPath);
    const sz = kid(pres, 'sldSz');
    const SW = px(attr(sz, 'cx') || 9144000), SH = px(attr(sz, 'cy') || 6858000);
    let ids = kids(kid(pres, 'sldIdLst'), 'sldId').map((s) => presRels[attr(s, 'r:id') || attr(s, 'id')]).filter(Boolean).map((r) => r.target);
    if (!ids.length) {   // dự phòng: lấy theo tên file slideN.xml
      ids = Object.keys(P.zip.files).filter((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n))
        .sort((a, b) => +a.match(/(\d+)\.xml$/)[1] - +b.match(/(\d+)\.xml$/)[1]);
    }
    if (!ids.length) throw new Error('Không tìm thấy slide nào trong file');
    const fit = opts.width / SW;
    const partCache = {};
    const getPart = async (p) => (partCache[p] = partCache[p] || partInfo(P, p));

    for (let i = 0; i < ids.length; i++) {
      if (opts.isCancelled()) return;
      if (opts.onProgress && (i === 0 || i % 3 === 0)) { opts.onProgress(i + 1, ids.length); await new Promise((r) => setTimeout(r, 0)); }
      const slide = await getPart(ids[i]);
      if (!slide) continue;
      const layoutPath = Object.values(slide.rels).find((r) => r.type === 'slideLayout');
      const layout = layoutPath ? await getPart(layoutPath.target) : null;
      const masterRel = layout && Object.values(layout.rels).find((r) => r.type === 'slideMaster');
      const master = masterRel ? await getPart(masterRel.target) : null;
      const themeRel = master && Object.values(master.rels).find((r) => r.type === 'theme');
      const theme = themeRel ? await themeOf(P, themeRel.target) : { colors: {}, fonts: {} };
      const cm = master ? kid(master.root, 'clrMap') : null;
      const clrMap = {};
      if (cm) for (const a of cm.attributes) clrMap[a.name] = a.value;
      const ctx = { P, theme: theme.colors, fonts: theme.fonts, clrMap, slide, layout, master, txStyles: master ? kid(master.root, 'txStyles') : null };

      const outer = document.createElement('div');
      outer.className = 'slide-outer';
      outer.style.width = SW + 'px';
      outer.style.height = SH + 'px';
      outer.style.marginBottom = (6 / fit) + 'px';
      const el = document.createElement('div');
      el.className = 'slide';
      el.style.width = SW + 'px';
      el.style.height = SH + 'px';
      outer.appendChild(el);
      host.appendChild(outer);
      const num = document.createElement('div');
      num.className = 'slide-num';
      num.style.fontSize = (12 / fit) + 'px';
      num.style.margin = `0 0 ${10 / fit}px`;
      num.textContent = (i + 1) + ' / ' + ids.length;
      host.appendChild(num);

      try {
        await applyBackground(el, [slide, layout, master].filter(Boolean), ctx);
        const ident = (x, y, w, h) => ({ x, y, w, h });
        if (master && attr(slide.root, 'showMasterSp') !== '0' && (!layout || attr(layout.root, 'showMasterSp') !== '0')) {
          await renderTree(master.spTree, el, { ...ctx, part: master, nonPhOnly: true }, ident);
        }
        if (layout && attr(slide.root, 'showMasterSp') !== '0') {
          await renderTree(layout.spTree, el, { ...ctx, part: layout, nonPhOnly: true }, ident);
        }
        await renderTree(slide.spTree, el, { ...ctx, part: slide }, ident);
      } catch (e) {
        console.error('slide', i + 1, e);
      }
    }
    return { slideWidth: SW, slideHeight: SH, count: ids.length };
  }

  async function themeOf(P, p) {
    const doc = await P.xml(p);
    const colors = {}, fonts = {};
    if (!doc) return { colors, fonts };
    const scheme = doc.getElementsByTagNameNS('*', 'clrScheme')[0];
    if (scheme) for (const c of scheme.children) {
      const s = kid(c, 'srgbClr'), y = kid(c, 'sysClr');
      colors[c.localName] = s ? attr(s, 'val') : y ? (attr(y, 'lastClr') || '000000') : '000000';
    }
    const fs = doc.getElementsByTagNameNS('*', 'fontScheme')[0];
    if (fs) {
      const mj = path(fs, 'majorFont', 'latin'), mn = path(fs, 'minorFont', 'latin');
      fonts.major = attr(mj, 'typeface'); fonts.minor = attr(mn, 'typeface');
    }
    return { colors, fonts };
  }

  async function applyBackground(el, parts, ctx) {
    for (const part of parts) {
      const bg = kid(part.cSld, 'bg');
      if (!bg) continue;
      const bgPr = kid(bg, 'bgPr');
      if (bgPr) {
        const f = fillOf(bgPr, ctx);
        if (f) { await applyFill(el, f, { ...ctx, part }); return; }
      }
      const ref = kid(bg, 'bgRef');
      if (ref) { const c = colorOf(ref, ctx); if (c) el.style.background = c; return; }
    }
  }
  async function applyFill(el, f, ctx) {
    if (!f || f.none) return;
    if (f.gradient) el.style.background = f.gradient;
    else if (f.color) el.style.background = f.color;
    else if (f.image) {
      const r = ctx.part.rels[f.image];
      const url = r && await ctx.P.media(r.target);
      if (url) { el.style.backgroundImage = `url(${url})`; el.style.backgroundSize = '100% 100%'; }
    }
  }

  function xfrmOf(spPr) {
    const x = kid(spPr, 'xfrm');
    if (!x) return null;
    const off = kid(x, 'off'), ext = kid(x, 'ext');
    if (!off || !ext) return null;
    return {
      x: px(attr(off, 'x')), y: px(attr(off, 'y')), w: px(attr(ext, 'cx')), h: px(attr(ext, 'cy')),
      rot: (+attr(x, 'rot') || 0) / 60000, flipH: attr(x, 'flipH') === '1', flipV: attr(x, 'flipV') === '1',
      chOff: kid(x, 'chOff'), chExt: kid(x, 'chExt'),
    };
  }

  function place(el, b, rot, flipH, flipV) {
    el.style.left = b.x + 'px'; el.style.top = b.y + 'px';
    el.style.width = Math.max(0, b.w) + 'px'; el.style.height = Math.max(0, b.h) + 'px';
    const t = [];
    if (rot) t.push(`rotate(${rot}deg)`);
    if (flipH) t.push('scaleX(-1)');
    if (flipV) t.push('scaleY(-1)');
    if (t.length) el.style.transform = t.join(' ');
  }

  async function renderTree(tree, host, ctx, tf) {
    if (!tree) return;
    for (const node of tree.children) {
      const n = node.localName;
      try {
        if (n === 'sp') await renderShape(node, host, ctx, tf);
        else if (n === 'pic') await renderPic(node, host, ctx, tf);
        else if (n === 'grpSp') await renderGroup(node, host, ctx, tf);
        else if (n === 'graphicFrame') await renderFrame(node, host, ctx, tf);
        else if (n === 'cxnSp') renderLine(node, host, ctx, tf);
        else if (n === 'AlternateContent') {
          const fb = kid(node, 'Fallback') || kid(node, 'Choice');
          if (fb) await renderTree(fb, host, ctx, tf);
        }
      } catch (e) { console.warn('shape error', e); }
    }
  }

  async function renderGroup(g, host, ctx, tf) {
    const x = xfrmOf(kid(g, 'grpSpPr'));
    if (!x || !x.chOff || !x.chExt) return renderTree(g, host, ctx, tf);
    const cx = px(attr(x.chOff, 'x')), cy = px(attr(x.chOff, 'y'));
    const cw = px(attr(x.chExt, 'cx')) || 1, ch = px(attr(x.chExt, 'cy')) || 1;
    const sx = x.w / cw, sy = x.h / ch;
    const inner = (a, b, w, h) => tf(x.x + (a - cx) * sx, x.y + (b - cy) * sy, w * sx, h * sy);
    await renderTree(g, host, ctx, inner);
  }

  function isPh(sp) { return !!path(sp, 'nvSpPr', 'nvPr', 'ph') || !!path(sp, 'nvPicPr', 'nvPr', 'ph'); }

  async function renderShape(sp, host, ctx, tf) {
    const ph = path(sp, 'nvSpPr', 'nvPr', 'ph');
    if (ph && ctx.nonPhOnly) return;          // placeholder của layout/master: chỉ là khung mẫu
    const phType = ph ? (attr(ph, 'type') || 'body') : null;
    const phIdx = ph ? attr(ph, 'idx') : null;
    if (ph && ['sldNum', 'dt', 'ftr'].includes(phType) && !hasText(sp)) return;

    // Kế thừa từ layout / master
    const inh = [];
    if (ph) {
      const l = findPh(ctx.layout, phType, phIdx); if (l) inh.push(l);
      const m = findPh(ctx.master, phType, l ? attr(path(l, 'nvSpPr', 'nvPr', 'ph'), 'idx') : phIdx); if (m) inh.push(m);
    }
    const spPr = kid(sp, 'spPr');
    let xf = xfrmOf(spPr);
    for (const s of inh) { if (xf) break; xf = xfrmOf(kid(s, 'spPr')); }
    if (!xf) return;
    const b = tf(xf.x, xf.y, xf.w, xf.h);

    const el = document.createElement('div');
    el.className = 'sh';
    place(el, b, xf.rot, false, false);

    // Fill & viền
    const style = kid(sp, 'style');
    let fill = fillOf(spPr, ctx);
    if (fill === undefined) for (const s of inh) { fill = fillOf(kid(s, 'spPr'), ctx); if (fill !== undefined) break; }
    if (fill === undefined && style) {
      const fr = kid(style, 'fillRef');
      if (fr && +attr(fr, 'idx') > 0) fill = { color: colorOf(fr, ctx) };
    }
    await applyFill(el, fill, ctx);
    const ln = kid(spPr, 'ln');
    let lnColor = null, lnW = 0;
    if (ln && !kid(ln, 'noFill')) {
      lnColor = colorOf(kid(ln, 'solidFill'), ctx);
      lnW = attr(ln, 'w') ? px(attr(ln, 'w')) : 1;
    }
    if (!ln && style) {
      const lr = kid(style, 'lnRef');
      if (lr && +attr(lr, 'idx') > 0) { lnColor = colorOf(lr, ctx); lnW = 1; }
    }
    if (lnColor) el.style.border = `${Math.max(0.75, lnW)}px solid ${lnColor}`;
    const geom = attr(kid(spPr, 'prstGeom'), 'prst');
    if (geom === 'ellipse') el.style.borderRadius = '50%';
    else if (geom === 'roundRect') el.style.borderRadius = Math.min(b.w, b.h) * 0.16 + 'px';

    // Text
    const txBody = kid(sp, 'txBody');
    if (txBody) {
      const fontRef = style ? kid(style, 'fontRef') : null;
      const defColor = fontRef ? colorOf(fontRef, ctx) : null;
      renderText(txBody, el, ctx, { phType, inh, defColor, isPh: !!ph });
    }
    if (xf.flipH || xf.flipV) { /* bỏ lật với text cho dễ đọc */ }
    host.appendChild(el);
  }

  function hasText(sp) { const t = sp.getElementsByTagNameNS('*', 't'); return Array.from(t).some((x) => x.textContent.trim()); }

  // Lấy thuộc tính mặc định của đoạn theo level từ: lstStyle shape -> lstStyle layout/master ph -> txStyles master
  function levelProps(txBody, ctx, info, lvl) {
    const key = 'lvl' + (lvl + 1) + 'pPr';
    const chain = [];
    const ls = kid(txBody, 'lstStyle'); if (ls && kid(ls, key)) chain.push(kid(ls, key));
    for (const s of info.inh) { const l = path(s, 'txBody', 'lstStyle'); if (l && kid(l, key)) chain.push(kid(l, key)); }
    if (ctx.txStyles) {
      const t = info.phType;
      const which = !info.isPh ? 'otherStyle' : (t === 'title' || t === 'ctrTitle') ? 'titleStyle' : (['body', 'subTitle', 'obj'].includes(t) || /^\d+$/.test(t)) ? 'bodyStyle' : 'otherStyle';
      const st = kid(ctx.txStyles, which);
      if (st && kid(st, key)) chain.push(kid(st, key));
    }
    return chain; // ưu tiên phần tử đầu
  }
  function pick(chain, fn) { for (const c of chain) { const v = fn(c); if (v != null) return v; } return null; }

  function fontFamily(tf, ctx) {
    if (!tf) return null;
    if (tf === '+mj-lt') tf = ctx.fonts.major; else if (tf === '+mn-lt') tf = ctx.fonts.minor;
    if (!tf || tf.startsWith('+')) return null;
    return `"${tf}", system-ui, sans-serif`;
  }

  function renderText(txBody, el, ctx, info) {
    const bodyPr = kid(txBody, 'bodyPr');
    const inhBody = info.inh.map((s) => path(s, 'txBody', 'bodyPr')).filter(Boolean);
    const bp = (name) => attr(bodyPr, name) ?? pick(inhBody, (b) => attr(b, name));
    const ins = (name, def) => { const v = bp(name); return px(v != null ? v : def); };
    el.style.padding = `${ins('tIns', 45720)}px ${ins('rIns', 91440)}px ${ins('bIns', 45720)}px ${ins('lIns', 91440)}px`;
    const anchor = bp('anchor') || (info.phType === 'title' || info.phType === 'ctrTitle' ? 'ctr' : 't');
    el.style.justifyContent = anchor === 'ctr' ? 'center' : anchor === 'b' ? 'flex-end' : 'flex-start';
    if (bp('wrap') === 'none') el.style.whiteSpace = 'nowrap';
    if (bp('vert') === 'vert' || bp('vert') === 'eaVert') el.style.writingMode = 'vertical-rl';
    let scale = 1, lnRed = 0;
    const af = kid(bodyPr, 'normAutofit') || pick(inhBody, (b) => kid(b, 'normAutofit'));
    if (af) { if (attr(af, 'fontScale')) scale = +attr(af, 'fontScale') / 100000; if (attr(af, 'lnSpcReduction')) lnRed = +attr(af, 'lnSpcReduction') / 100000; }

    const autoNum = {};
    for (const p of kids(txBody, 'p')) {
      const pPr = kid(p, 'pPr');
      const lvl = +attr(pPr, 'lvl') || 0;
      const chain = [pPr, ...levelProps(txBody, ctx, info, lvl)].filter(Boolean);
      const pe = document.createElement('p');
      const algn = pick(chain, (c) => attr(c, 'algn')) || 'l';
      pe.style.textAlign = { l: 'left', ctr: 'center', r: 'right', just: 'justify', dist: 'justify' }[algn] || 'left';
      const marL = pick(chain, (c) => attr(c, 'marL'));
      const indent = pick(chain, (c) => attr(c, 'indent'));
      if (marL != null) pe.style.paddingLeft = px(marL) + 'px';
      if (indent != null) pe.style.textIndent = px(indent) + 'px';
      const lnPct = pick(chain, (c) => attr(path(c, 'lnSpc', 'spcPct'), 'val'));
      pe.style.lineHeight = ((lnPct ? +lnPct / 100000 : 1) * 1.17 * (1 - lnRed)).toFixed(3);
      const spcBef = pick(chain, (c) => attr(path(c, 'spcBef', 'spcPts'), 'val'));
      if (spcBef) pe.style.marginTop = (+spcBef / 100) * PT_PX * scale + 'px';
      const spcAft = pick(chain, (c) => attr(path(c, 'spcAft', 'spcPts'), 'val'));
      if (spcAft) pe.style.marginBottom = (+spcAft / 100) * PT_PX * scale + 'px';

      // style mặc định của run
      const defRPrs = chain.map((c) => kid(c, 'defRPr')).filter(Boolean);
      const endRPr = kid(p, 'endParaRPr');
      const runs = Array.from(p.children).filter((c) => ['r', 'br', 'fld'].includes(c.localName));
      const hasContent = runs.some((r) => r.localName !== 'br' && (kid(r, 't')?.textContent || '').length);

      // Bullet
      if (hasContent && !pick(chain, (c) => (kid(c, 'buNone') ? 'none' : null))) {
        const bc = pick(chain, (c) => attr(kid(c, 'buChar'), 'char'));
        const an = pick(chain, (c) => kid(c, 'buAutoNum'));
        let bullet = null;
        if (bc) bullet = bc;
        else if (an) { autoNum[lvl] = (autoNum[lvl] || +attr(an, 'startAt') || 1) ; bullet = formatNum(attr(an, 'type'), autoNum[lvl]); autoNum[lvl]++; }
        if (bullet) {
          const s = document.createElement('span');
          s.textContent = bullet + ' ';
          const firstR = runs.find((r) => r.localName === 'r');
          applyRun(s, [kid(firstR, 'rPr'), ...defRPrs], ctx, info, scale);
          const buClr = pick(chain, (c) => kid(c, 'buClr'));
          if (buClr) s.style.color = colorOf(buClr, ctx);
          if (/^[-]$/.test(bullet) || ['§', 'Ø', 'ü', 'q', 'n', 'l', 'Ÿ'].includes(bullet)) s.textContent = '• '; // ký tự Wingdings
          pe.appendChild(s);
        }
      } else if (!pick(chain, (c) => (kid(c, 'buAutoNum') ? 1 : null))) {
        // không đánh số thì reset
      }

      for (const r of runs) {
        if (r.localName === 'br') { pe.appendChild(document.createElement('br')); continue; }
        const t = kid(r, 't');
        const s = document.createElement('span');
        s.textContent = t ? t.textContent : '';
        applyRun(s, [kid(r, 'rPr'), ...defRPrs], ctx, info, scale);
        const link = path(r, 'rPr', 'hlinkClick');
        if (link) { s.style.textDecoration = 'underline'; if (!kid(kid(r, 'rPr'), 'solidFill')) s.style.color = '#' + (ctx.theme.hlink || '0563C1'); }
        pe.appendChild(s);
      }
      if (!hasContent) {
        const s = document.createElement('span');
        s.textContent = ' ';
        applyRun(s, [endRPr, ...defRPrs], ctx, info, scale);
        pe.appendChild(s);
      }
      el.appendChild(pe);
    }
  }

  function formatNum(type, n) {
    type = type || 'arabicPeriod';
    const roman = (x) => { const m = [[1000, 'm'], [900, 'cm'], [500, 'd'], [400, 'cd'], [100, 'c'], [90, 'xc'], [50, 'l'], [40, 'xl'], [10, 'x'], [9, 'ix'], [5, 'v'], [4, 'iv'], [1, 'i']]; let s = ''; for (const [v, r] of m) while (x >= v) { s += r; x -= v; } return s; };
    let core = String(n);
    if (type.startsWith('alphaLc')) core = String.fromCharCode(96 + ((n - 1) % 26) + 1);
    else if (type.startsWith('alphaUc')) core = String.fromCharCode(64 + ((n - 1) % 26) + 1);
    else if (type.startsWith('romanLc')) core = roman(n);
    else if (type.startsWith('romanUc')) core = roman(n).toUpperCase();
    if (type.endsWith('ParenR')) return core + ')';
    if (type.endsWith('ParenBoth')) return '(' + core + ')';
    if (type.endsWith('Plain')) return core;
    return core + '.';
  }

  function applyRun(s, rprs, ctx, info, scale) {
    const own = rprs[0];
    rprs = rprs.filter(Boolean);
    const a = (n) => pick(rprs, (r) => attr(r, n));
    const sz = a('sz');
    s.style.fontSize = ((sz ? +sz / 100 : 18) * PT_PX * scale).toFixed(2) + 'px';
    if (a('b') === '1') s.style.fontWeight = '700';
    if (a('i') === '1') s.style.fontStyle = 'italic';
    const u = a('u'); const strike = a('strike');
    const deco = [];
    if (u && u !== 'none') deco.push('underline');
    if (strike && strike !== 'noStrike') deco.push('line-through');
    if (deco.length) s.style.textDecoration = deco.join(' ');
    const base = a('baseline');
    if (base && +base !== 0) { s.style.verticalAlign = +base > 0 ? 'super' : 'sub'; s.style.fontSize = parseFloat(s.style.fontSize) * 0.65 + 'px'; }
    const cap = a('cap');
    if (cap === 'all') s.style.textTransform = 'uppercase';
    const color = colorOf(kid(own, 'solidFill'), ctx) || info.defColor || pick(rprs, (r) => colorOf(kid(r, 'solidFill'), ctx)) || ('#' + (ctx.theme[ctx.clrMap.tx1 || 'dk1'] || '000000'));
    s.style.color = color;
    const hl = pick(rprs, (r) => colorOf(kid(r, 'highlight'), ctx));
    if (hl) s.style.background = hl;
    let ff = pick(rprs, (r) => attr(kid(r, 'latin'), 'typeface')) || pick(rprs, (r) => attr(kid(r, 'ea'), 'typeface'));
    if (!ff) ff = (info.phType === 'title' || info.phType === 'ctrTitle') ? '+mj-lt' : '+mn-lt';
    const fam = fontFamily(ff, ctx);
    if (fam) s.style.fontFamily = fam;
  }

  async function renderPic(pic, host, ctx, tf) {
    if (ctx.nonPhOnly && isPh(pic)) return;
    const spPr = kid(pic, 'spPr');
    let xf = xfrmOf(spPr);
    if (!xf) {
      const ph = path(pic, 'nvPicPr', 'nvPr', 'ph');
      if (ph) {
        const l = findPh(ctx.layout, attr(ph, 'type') || 'body', attr(ph, 'idx'));
        xf = l && xfrmOf(kid(l, 'spPr'));
      }
    }
    if (!xf) return;
    const blip = path(pic, 'blipFill', 'blip');
    const rid = attr(blip, 'r:embed') || attr(blip, 'embed');
    const r = rid && ctx.part.rels[rid];
    const url = r && await ctx.P.media(r.target);
    const b = tf(xf.x, xf.y, xf.w, xf.h);
    if (!url) return;
    // crop
    const src = path(pic, 'blipFill', 'srcRect');
    const wrap = document.createElement('div');
    wrap.className = 'sh';
    wrap.style.overflow = 'hidden';
    place(wrap, b, xf.rot, xf.flipH, xf.flipV);
    const img = document.createElement('img');
    img.className = 'pic';
    img.src = url;
    const l = +attr(src, 'l') / 100000 || 0, t = +attr(src, 't') / 100000 || 0, rr = +attr(src, 'r') / 100000 || 0, bb = +attr(src, 'b') / 100000 || 0;
    const fw = 1 - l - rr || 1, fh = 1 - t - bb || 1;
    img.style.width = (b.w / fw) + 'px'; img.style.height = (b.h / fh) + 'px';
    img.style.left = (-l * b.w / fw) + 'px'; img.style.top = (-t * b.h / fh) + 'px';
    if (attr(kid(spPr, 'prstGeom'), 'prst') === 'ellipse') wrap.style.borderRadius = '50%';
    wrap.appendChild(img);
    host.appendChild(wrap);
  }

  function renderLine(cxn, host, ctx, tf) {
    const spPr = kid(cxn, 'spPr');
    const xf = xfrmOf(spPr);
    if (!xf) return;
    const b = tf(xf.x, xf.y, xf.w, xf.h);
    const ln = kid(spPr, 'ln');
    let color = ln && colorOf(kid(ln, 'solidFill'), ctx);
    const style = kid(cxn, 'style');
    if (!color && style) color = colorOf(kid(style, 'lnRef'), ctx);
    color = color || '#000';
    const w = ln && attr(ln, 'w') ? Math.max(1, px(attr(ln, 'w'))) : 1;
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('class', 'sh');
    svg.style.position = 'absolute'; svg.style.overflow = 'visible';
    place(svg, { x: b.x, y: b.y, w: Math.max(b.w, 1), h: Math.max(b.h, 1) }, xf.rot, false, false);
    const line = document.createElementNS(ns, 'line');
    let x1 = 0, y1 = 0, x2 = b.w, y2 = b.h;
    if (xf.flipH) { x1 = b.w; x2 = 0; }
    if (xf.flipV) { y1 = b.h; y2 = 0; }
    line.setAttribute('x1', x1); line.setAttribute('y1', y1); line.setAttribute('x2', x2); line.setAttribute('y2', y2);
    line.setAttribute('stroke', color); line.setAttribute('stroke-width', w);
    if (ln && kid(ln, 'prstDash') && attr(kid(ln, 'prstDash'), 'val') !== 'solid') line.setAttribute('stroke-dasharray', `${w * 3} ${w * 2}`);
    svg.appendChild(line);
    host.appendChild(svg);
  }

  async function renderFrame(gf, host, ctx, tf) {
    const x = kid(gf, 'xfrm');
    if (!x) return;
    const off = kid(x, 'off'), ext = kid(x, 'ext');
    const b = tf(px(attr(off, 'x')), px(attr(off, 'y')), px(attr(ext, 'cx')), px(attr(ext, 'cy')));
    const gd = path(gf, 'graphic', 'graphicData');
    const tbl = kid(gd, 'tbl');
    if (tbl) return renderTable(tbl, host, ctx, b);
    // Biểu đồ / SmartArt / OLE: hiển thị khung
    const uri = attr(gd, 'uri') || '';
    const box = document.createElement('div');
    box.className = 'sh';
    place(box, b, 0, false, false);
    box.style.border = '1px dashed #9ca3af';
    box.style.justifyContent = 'center';
    box.style.alignItems = 'center';
    box.style.color = '#6b7280';
    box.style.fontSize = '20px';
    box.style.background = 'rgba(243,244,246,.6)';
    box.textContent = uri.includes('chart') ? '📊 Biểu đồ' : uri.includes('diagram') ? 'SmartArt' : 'Đối tượng nhúng';
    // thử lấy ảnh dự phòng của OLE
    const pic = gf.getElementsByTagNameNS('*', 'pic')[0];
    if (pic) {
      const blip = pic.getElementsByTagNameNS('*', 'blip')[0];
      const rid = blip && (attr(blip, 'r:embed') || attr(blip, 'embed'));
      const r = rid && ctx.part.rels[rid];
      const url = r && await ctx.P.media(r.target);
      if (url) { box.textContent = ''; box.style.border = '0'; box.style.background = `url(${url}) center/100% 100% no-repeat`; }
    }
    host.appendChild(box);
  }

  function renderTable(tbl, host, ctx, b) {
    const t = document.createElement('table');
    t.className = 'tbl';
    t.style.left = b.x + 'px'; t.style.top = b.y + 'px'; t.style.width = b.w + 'px';
    const cg = document.createElement('colgroup');
    for (const g of kids(kid(tbl, 'tblGrid'), 'gridCol')) { const c = document.createElement('col'); c.style.width = px(attr(g, 'w')) + 'px'; cg.appendChild(c); }
    t.appendChild(cg);
    const tblPr = kid(tbl, 'tblPr');
    const firstRow = attr(tblPr, 'firstRow') === '1', band = attr(tblPr, 'bandRow') === '1';
    const accent = '#' + (ctx.theme.accent1 || '4472C4');
    kids(tbl, 'tr').forEach((tr, ri) => {
      const row = document.createElement('tr');
      row.style.height = px(attr(tr, 'h')) + 'px';
      for (const tc of kids(tr, 'tc')) {
        if (attr(tc, 'hMerge') === '1' || attr(tc, 'vMerge') === '1') continue;
        const td = document.createElement('td');
        if (attr(tc, 'gridSpan')) td.colSpan = +attr(tc, 'gridSpan');
        if (attr(tc, 'rowSpan')) td.rowSpan = +attr(tc, 'rowSpan');
        const tcPr = kid(tc, 'tcPr');
        const f = fillOf(tcPr, ctx);
        let defColor = null;
        if (f && f.color) td.style.background = f.color;
        else if (f === undefined && firstRow && ri === 0) { td.style.background = accent; defColor = '#fff'; }
        else if (f === undefined && band) td.style.background = ri % 2 ? '#e9edf6' : '#cfd8ea';
        if (firstRow && ri === 0 && !defColor) defColor = null;
        const anchor = attr(tcPr, 'anchor');
        td.style.verticalAlign = anchor === 'ctr' ? 'middle' : anchor === 'b' ? 'bottom' : 'top';
        const cell = document.createElement('div');
        cell.style.padding = `${px(attr(tcPr, 'marT') ?? 45720)}px ${px(attr(tcPr, 'marR') ?? 91440)}px ${px(attr(tcPr, 'marB') ?? 45720)}px ${px(attr(tcPr, 'marL') ?? 91440)}px`;
        const txBody = kid(tc, 'txBody');
        if (txBody) {
          const tmp = document.createElement('div');
          renderText(txBody, tmp, ctx, { phType: null, inh: [], defColor, isPh: false });
          tmp.style.padding = '0';
          while (tmp.firstChild) cell.appendChild(tmp.firstChild);
          if (firstRow && ri === 0) cell.querySelectorAll('span').forEach((s) => { s.style.fontWeight = '700'; });
        }
        // viền
        for (const [side, nm] of [['Left', 'lnL'], ['Right', 'lnR'], ['Top', 'lnT'], ['Bottom', 'lnB']]) {
          const l = kid(tcPr, nm);
          if (l) {
            const c = kid(l, 'noFill') ? 'transparent' : colorOf(kid(l, 'solidFill'), ctx);
            if (c) td.style['border' + side] = `${Math.max(1, px(attr(l, 'w') || 12700))}px solid ${c}`;
          }
        }
        td.appendChild(cell);
        row.appendChild(td);
      }
      t.appendChild(row);
    });
    host.appendChild(t);
  }

  window.PptxRender = { render };
})();
