package vn.dang.docviewer

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.Color
import android.view.View
import android.widget.LinearLayout
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    data class Doc(val uri: Uri, val name: String, val mime: String, val size: Long)

    private lateinit var web: WebView
    private val io = Executors.newSingleThreadExecutor()
    private var current: Doc? = null
    private var pageReady = false
    private var pendingDoc: Doc? = null
    private val recents by lazy { RecentStore(this) }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) { }
            val doc = describe(uri)
            recents.add(doc)
            showDoc(doc)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/doc/", WebViewAssetLoader.PathHandler { _ ->
                val doc = current ?: return@PathHandler null
                try {
                    val input = contentResolver.openInputStream(doc.uri) ?: return@PathHandler null
                    WebResourceResponse(doc.mime, null, input)
                } catch (e: Exception) {
                    WebResourceResponse("text/plain", "utf-8", 404, "Not found", null, null)
                }
            })
            .build()

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            // Zoom do giao diện tự xử lý (zoom.js) để thanh công cụ luôn cố định
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            webChromeClient = WebChromeClient()   // cho phép confirm()/prompt() (mật khẩu PDF)
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val url = request.url
                    if (url.host == WebViewAssetLoader.DEFAULT_DOMAIN) return false
                    // link trong tài liệu -> mở bằng trình duyệt ngoài
                    try { startActivity(Intent(Intent.ACTION_VIEW, url)) } catch (_: Exception) { }
                    return true
                }
            }
            addJavascriptInterface(Bridge(), "Android")
        }
        setContentView(buildRoot())
        web.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/viewer/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.App ? App.back() : false") { r ->
                    if (r != "true") finish()
                }
            }
        })

        handleIntent(intent)
    }

    /**
     * Android 15+ vẽ app tràn dưới thanh trạng thái & thanh điều hướng.
     * Chừa riêng 2 vùng đó (dải xanh phía trên, dải trắng phía dưới) để nút bấm của app không bị đè.
     */
    private fun buildRoot(): View {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val topBar = View(this).apply { setBackgroundColor(Color.parseColor("#1A5FB4")) }
        val bottomBar = View(this).apply { setBackgroundColor(Color.WHITE) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            addView(topBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0))
            addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(bottomBar, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0))
        }
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            topBar.layoutParams = topBar.layoutParams.apply { height = bars.top }
            bottomBar.layoutParams = bottomBar.layoutParams.apply { height = bars.bottom }
            v.setPadding(bars.left, 0, bars.right, 0)
            topBar.requestLayout()
            WindowInsetsCompat.CONSUMED
        }
        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = false     // chữ/biểu tượng trắng trên nền xanh
            isAppearanceLightNavigationBars = true  // biểu tượng tối trên nền trắng
        }
        return root
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** File gửi tới từ app khác: "Mở bằng" (VIEW) hoặc "Chia sẻ" (SEND) */
    private fun handleIntent(intent: Intent?) {
        intent ?: return
        val uri: Uri = when (intent.action) {
            Intent.ACTION_VIEW -> intent.data
            Intent.ACTION_SEND -> streamExtra(intent)
            else -> null
        } ?: return
        intent.action = null // tránh mở lại khi xoay màn hình
        runJs("App.setLoading(true,'Đang nhận file…')")
        io.execute {
            try {
                // Quyền đọc từ Zalo/Gmail chỉ tạm thời -> chép về bộ nhớ app để mở lại sau
                val src = describe(uri)
                val dir = File(filesDir, "received").apply { mkdirs() }
                val dest = uniqueFile(dir, src.name)
                contentResolver.openInputStream(uri)!!.use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
                val doc = Doc(Uri.fromFile(dest), src.name, src.mime, dest.length())
                recents.add(doc)
                runOnUiThread { showDoc(doc) }
            } catch (e: Exception) {
                runOnUiThread {
                    runJs("App.setLoading(false)")
                    toast("Không đọc được file: ${e.message}")
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun streamExtra(intent: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)

    private fun uniqueFile(dir: File, name: String): File {
        val safe = name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        var f = File(dir, safe)
        if (!f.exists()) return f
        val dot = safe.lastIndexOf('.')
        val base = if (dot > 0) safe.substring(0, dot) else safe
        val ext = if (dot > 0) safe.substring(dot) else ""
        var i = 1
        while (f.exists()) { f = File(dir, "$base ($i)$ext"); i++ }
        return f
    }

    private fun describe(uri: Uri): Doc {
        var name: String? = null
        var size = -1L
        if (uri.scheme == "file") {
            val f = File(uri.path!!)
            name = f.name; size = f.length()
        } else try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (_: Exception) { }
        val finalName = name ?: uri.lastPathSegment?.substringAfterLast('/') ?: "tai-lieu"
        var mime = if (uri.scheme == "file") null else contentResolver.getType(uri)
        if (mime == null || mime == "application/octet-stream") {
            val ext = finalName.substringAfterLast('.', "").lowercase()
            mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: mime ?: "application/octet-stream"
        }
        return Doc(uri, finalName, mime, size)
    }

    private fun showDoc(doc: Doc) {
        current = doc
        if (!pageReady) { pendingDoc = doc; return }
        val js = JSONObject()
            .put("name", doc.name)
            .put("mime", doc.mime)
            .put("size", doc.size)
            .put("url", "/doc/file?t=${System.currentTimeMillis()}")
        runJs("App.onFile($js)")
    }

    private fun runJs(js: String) {
        if (pageReady) web.evaluateJavascript(js, null)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    /** Chép file hiện tại vào cache/share để cấp quyền cho app khác qua FileProvider */
    private fun withShareUri(block: (Uri, Doc) -> Unit) {
        val doc = current ?: return
        io.execute {
            try {
                val dir = File(cacheDir, "share").apply { mkdirs(); listFiles()?.forEach { it.delete() } }
                val out = File(dir, doc.name.replace(Regex("[\\\\/:*?\"<>|]"), "_"))
                contentResolver.openInputStream(doc.uri)!!.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                val uri = FileProvider.getUriForFile(this, "$packageName.files", out)
                runOnUiThread { block(uri, doc) }
            } catch (e: Exception) {
                runOnUiThread { toast("Lỗi: ${e.message}") }
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun ready() = runOnUiThread {
            pageReady = true
            pendingDoc?.let { pendingDoc = null; showDoc(it) }
        }

        @JavascriptInterface
        fun pickFile() = runOnUiThread {
            // */* để mọi trình quản lý file đều cho chọn tài liệu (một số máy báo sai loại file)
            picker.launch(arrayOf("*/*"))
        }

        @JavascriptInterface
        fun share() = runOnUiThread {
            withShareUri { uri, doc ->
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = doc.mime
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_SUBJECT, doc.name)
                    clipData = ClipData.newRawUri(doc.name, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(send, "Chia sẻ \"${doc.name}\""))
            }
        }

        @JavascriptInterface
        fun openWith() = runOnUiThread {
            withShareUri { uri, doc ->
                val view = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, doc.mime)
                    clipData = ClipData.newRawUri(doc.name, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try {
                    startActivity(Intent.createChooser(view, "Mở bằng"))
                } catch (e: Exception) {
                    toast("Không có app nào mở được file này")
                }
            }
        }

        @JavascriptInterface
        fun getRecents(): String = recents.json()

        @JavascriptInterface
        fun openRecent(uriStr: String) = runOnUiThread {
            val uri = Uri.parse(uriStr)
            val ok = try { contentResolver.openInputStream(uri)?.close(); true } catch (_: Exception) { false }
            if (!ok) {
                toast("File không còn truy cập được (đã xoá hoặc bị thu hồi quyền)")
                recents.remove(uriStr)
                runJs("App.refreshRecents()")
                return@runOnUiThread
            }
            val old = recents.find(uriStr)
            val doc = describe(uri).let { d -> if (old != null) d.copy(name = old.optString("name", d.name)) else d }
            recents.add(doc)
            showDoc(doc)
        }

        @JavascriptInterface
        fun removeRecent(uriStr: String) = recents.remove(uriStr)

        @JavascriptInterface
        fun clearRecents() = recents.clear()

        @JavascriptInterface
        fun toast(msg: String) {
            runOnUiThread { this@MainActivity.toast(msg) }
        }
    }

    /** Lịch sử file gần đây (SharedPreferences, tối đa 50) */
    inner class RecentStore(ctx: ComponentActivity) {
        private val prefs = ctx.getSharedPreferences("recents", Context.MODE_PRIVATE)
        private fun load(): JSONArray = try { JSONArray(prefs.getString("list", "[]")) } catch (_: Exception) { JSONArray() }
        private fun save(a: JSONArray) = prefs.edit().putString("list", a.toString()).apply()

        @Synchronized fun json(): String = load().toString()

        @Synchronized fun find(uri: String): JSONObject? {
            val a = load()
            for (i in 0 until a.length()) if (a.getJSONObject(i).optString("uri") == uri) return a.getJSONObject(i)
            return null
        }

        @Synchronized fun add(d: Doc) {
            val a = load()
            val out = JSONArray()
            out.put(JSONObject().put("uri", d.uri.toString()).put("name", d.name).put("mime", d.mime)
                .put("size", d.size).put("time", System.currentTimeMillis()))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                if (o.optString("uri") != d.uri.toString() && out.length() < 50) out.put(o)
                else if (o.optString("uri") != d.uri.toString()) deleteLocal(o.optString("uri"))
            }
            save(out)
        }

        @Synchronized fun remove(uri: String) {
            val a = load()
            val out = JSONArray()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                if (o.optString("uri") == uri) deleteLocal(uri) else out.put(o)
            }
            save(out)
        }

        @Synchronized fun clear() {
            val a = load()
            for (i in 0 until a.length()) deleteLocal(a.getJSONObject(i).optString("uri"))
            save(JSONArray())
        }

        /** Xoá bản sao file đã nhận (chỉ file trong bộ nhớ app) */
        private fun deleteLocal(uri: String) {
            val u = Uri.parse(uri)
            if (u.scheme == "file") {
                val f = File(u.path ?: return)
                if (f.absolutePath.startsWith(filesDir.absolutePath)) f.delete()
            } else {
                try { contentResolver.releasePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            }
        }
    }
}
