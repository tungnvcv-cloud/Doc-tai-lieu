plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "vn.dang.docviewer"
    compileSdk = 35

    defaultConfig {
        applicationId = "vn.dang.docviewer"
        minSdk = 26          // Android 8.0 trở lên
        targetSdk = 35
        versionCode = 3
        versionName = "1.3"
    }

    // Khoá ký cố định để cài đè bản mới không phải gỡ bản cũ
    signingConfigs {
        create("release") {
            storeFile = file("release.jks")
            storePassword = "docviewer123"
            keyAlias = "docviewer"
            keyPassword = "docviewer123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            signingConfig = signingConfigs.getByName("release")
        }
    }

    buildFeatures { buildConfig = true }

    // Không để kiểm tra lint chặn bản build
    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    androidResources {
        // không nén các file thư viện JS/bản đồ font lớn
        noCompress += listOf("bcmap", "pfb")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
}
