# Xem Tài Liệu – app Android xem & chia sẻ nhanh PDF, Word, Excel, PowerPoint

## Tính năng
- Xem **PDF**, **Word (.docx)**, **Excel (.xlsx, .xls, .csv, .ods)**, **PowerPoint (.pptx)**, ảnh, file text.
- Chụm 2 ngón để phóng to; Excel có tab chuyển sheet; PDF có số trang.
- **Chia sẻ** file đang xem sang Zalo, Gmail, Messenger, Drive… (nút chia sẻ góc phải).
- **Mở bằng app khác** (Word, WPS, Adobe…) khi cần sửa.
- App hiện trong danh sách **"Mở bằng"** và **"Chia sẻ"** của Zalo, Gmail, trình quản lý file.
- Lịch sử **file gần đây**; file nhận từ Zalo/Gmail được lưu bản sao để mở lại sau.
- Chạy offline hoàn toàn, không cần quyền Internet và không gửi file đi đâu.

Giới hạn: file .doc/.ppt đời cũ (trước 2007) chưa xem được, nhưng vẫn chia sẻ hoặc mở bằng app khác được. Biểu đồ và SmartArt trong PowerPoint chỉ hiện dạng khung.

## Cách 1 – Build bằng GitHub (không cần cài gì trên máy)
1. Tạo tài khoản GitHub, tạo repo mới (để Private cũng được).
2. Giải nén file zip, upload **toàn bộ** thư mục (gồm cả `.github`) lên repo:
   - Trên web: *Add file → Upload files*, kéo thả hết các file/thư mục vào.
   - Hoặc bằng git: `git init && git add . && git commit -m init && git remote add origin <url> && git push -u origin main`
3. Vào tab **Actions**, workflow **Build APK** tự chạy (khoảng 3–5 phút).
4. Mở lần chạy đó, kéo xuống mục **Artifacts**, tải **XemTaiLieu-apk** (file zip chứa `app-release.apk`).
5. Chép APK vào điện thoại, mở file và cho phép *"Cài ứng dụng không rõ nguồn gốc"*.

## Cách 2 – Android Studio
Mở thư mục `DocViewer` bằng Android Studio, đợi Gradle sync xong, cắm điện thoại (bật USB debugging) rồi bấm ▶ Run.
Hoặc chọn *Build → Build APK(s)*.

## Cấu trúc
```
app/src/main/java/vn/dang/docviewer/MainActivity.kt   – WebView, nhận/chia sẻ file, lịch sử
app/src/main/assets/viewer/index.html, app.js, style.css – giao diện
app/src/main/assets/viewer/pptx.js                     – bộ dựng slide PowerPoint
app/src/main/assets/viewer/lib/                        – pdf.js, docx-preview, SheetJS, JSZip
app/release.jks                                        – khoá ký app (mật khẩu: docviewer123)
```
Ghi chú: các bản build đều dùng chung khoá `release.jks`, nên bản mới cài đè lên bản cũ mà không phải gỡ. Đừng xoá file này.
